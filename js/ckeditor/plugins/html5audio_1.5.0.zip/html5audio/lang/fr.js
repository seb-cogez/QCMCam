CKEDITOR.plugins.setLang( 'html5audio', 'fr', {
    button: 'Insérer un lecteur audio HTML5',
    title: 'HTML5 audio',
    infoLabel: 'Informations audio',
    urlMissing: 'URL de la source audio manquante. Veuillez la renseigner.',
    audioProperties: 'Propriétés Audio',
    upload: 'Télécharger',
    btnUpload: 'Envoyer vers le serveur',
    advanced: 'Avancé',
    autoplay: 'Jouer automatiquement ?',
    allowdownload: 'Autoriser le téléchargement?',
    advisorytitle: 'Advisory title',
    yes: 'Oui',
    no: 'Non'
} );
