/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sr', {
	border: 'Прикажи границу оквира',
	noUrl: 'Унесите  iframe УРЛ',
	scrolling: 'Укљзчи померајуће траке.',
	title: 'IFrame подешавање',
	toolbar: 'IFrame'
} );
