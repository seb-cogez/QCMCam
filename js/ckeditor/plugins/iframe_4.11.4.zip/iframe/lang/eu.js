/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'eu', {
	border: 'Erakutsi markoaren ertza',
	noUrl: 'Idatzi iframe-aren URLa, mesedez.',
	scrolling: 'Gaitu korritze-barrak',
	title: 'IFrame-aren propietateak',
	toolbar: 'IFrame-a'
} );
