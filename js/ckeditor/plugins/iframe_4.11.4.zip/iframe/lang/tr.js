/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'tr', {
	border: 'Çerceve sınırlarını göster',
	noUrl: 'Lütfen IFrame köprü (URL) bağlantısını yazın',
	scrolling: 'Kaydırma çubuklarını aktif et',
	title: 'IFrame Özellikleri',
	toolbar: 'IFrame'
} );
