/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'en-gb', {
	border: 'Show frame border',
	noUrl: 'Please type the iframe URL',
	scrolling: 'Enable scrollbars',
	title: 'IFrame Properties',
	toolbar: 'IFrame'
} );
